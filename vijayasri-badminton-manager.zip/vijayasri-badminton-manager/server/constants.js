module.exports = {
    COMMITTEE_PHONES: [
        "9663111993", // Vignesh
        "7760268450", // Prabhu
        "9989155758" // Subir
    ]
};
